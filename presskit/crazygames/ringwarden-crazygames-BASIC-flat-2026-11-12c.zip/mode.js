// Chooses the view before the game starts: 3D (default) or Classic 2D (the v2 look and maps).
// The choice is saved per device; the main menu has a switch. Devices without WebGL get Classic 2D.
//   ?view=2d / ?view=3d   force a view (testing)
//   ?headless=1           run 3D maps without drawing anything (automated balance tests)
window.OD = window.OD || {};
(function (OD) {
  "use strict";
  const params = new URLSearchParams(location.search);
  let saved = null;
  try { saved = localStorage.getItem("od_view"); } catch { /* storage blocked */ }
  let view = params.get("view") || saved || "2d"; // everyone starts in 2D (Version C); 3D is one tap away in the menu
  const webgl = (() => {
    try { const c = document.createElement("canvas"); return !!(window.WebGLRenderingContext && (c.getContext("webgl2") || c.getContext("webgl"))); }
    catch { return false; }
  })();
  OD.webgl = webgl;
  if (view === "3d" && !webgl) view = "2d";
  OD.view = view;
  OD.is3D = view === "3d";
  OD.headless = params.get("headless") === "1";
  // Own Orbits (2D and 3D): every satellite launches onto its own orbit (LEO / MEO / HEO) and carries fuel.
  // ?orbits=classic (or localStorage od_orbits = "classic") brings the old shared ring slots back: used by the
  // automated tests of the slot-based mechanics.
  let orbits = params.get("orbits");
  if (!orbits) try { orbits = localStorage.getItem("od_orbits"); } catch { /* storage blocked */ }
  OD.EXP = orbits !== "classic" ? "orbits" : null;
  if (OD.is3D) {
    window.OD_NO2D = true;            // the 3D view does the drawing
    OD.apply3DMaps();                 // bigger planets, tilted orbits
    document.documentElement.classList.add("mode-3d");
  }
  // Switch view (saved), then reload so the right maps and renderer start fresh.
  OD.setView = function (v) {
    try { localStorage.setItem("od_view", v); } catch { /* ignore */ }
    const url = new URL(location.href); url.searchParams.delete("view");
    location.replace(url.toString());
  };
})(window.OD);
